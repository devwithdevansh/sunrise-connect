import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../data/models/fee_model.dart';
import '../../../dashboard/controllers/dashboard_controller.dart';

// ─────────────────────────────────────────────────────────────────────────
// CLASSIFICATION
//
// Ideally your API/Mongo fee documents already carry a `category`
// ("education" | "transport") and a `periodType` ("monthly" | "term" |
// "annual") field — that's the cleanest long-term setup. Until FeeModel
// exposes those, this extension infers them from `termName` so the UI
// still groups sensibly today. Swap the body of these getters for direct
// field reads as soon as the backend supports it (search "TODO: backend").
// ─────────────────────────────────────────────────────────────────────────

enum FeeCategory { education, transport, other }

enum FeePeriod { monthly, term, annual, other }

extension _FeeClassification on String {
  FeeCategory get inferredCategory {
    final t = toLowerCase();
    if (t.contains('transport') || t.contains('bus')) return FeeCategory.transport;
    return FeeCategory.education;
  }

  FeePeriod get inferredPeriod {
    final t = toLowerCase();
    if (t.contains('admission') || t.contains('annual') || t.contains('bag')) {
      return FeePeriod.annual;
    }
    if (t.contains('term') || t.contains('half') || t.contains('semester')) {
      return FeePeriod.term;
    }
    return FeePeriod.monthly;
  }
}

extension _FeeCategoryX on FeeCategory {
  String get label => switch (this) {
        FeeCategory.education => 'Education',
        FeeCategory.transport => 'Transport',
        FeeCategory.other => 'Other',
      };

  String get icon => switch (this) {
        FeeCategory.education => '📚',
        FeeCategory.transport => '🚌',
        FeeCategory.other => '🧾',
      };
}

extension _FeePeriodX on FeePeriod {
  String get label => switch (this) {
        FeePeriod.monthly => 'Monthly Fees',
        FeePeriod.term => 'Term Fees (Half-Yearly)',
        FeePeriod.annual => 'Annual / One-Time Fees',
        FeePeriod.other => 'Other Fees',
      };

  String get icon => switch (this) {
        FeePeriod.monthly => '📅',
        FeePeriod.term => '📦',
        FeePeriod.annual => '🎓',
        FeePeriod.other => '🧾',
      };
}

// ─────────────────────────────────────────────────────────────────────────
// SMALL HELPERS
// ─────────────────────────────────────────────────────────────────────────

bool _isOverdue(FeeModel fee) {
  final due = DateTime.tryParse(fee.dueDate) ?? DateTime.now();
  return due.isBefore(DateTime.now());
}

int _daysOverdueOrUntilDue(FeeModel fee) {
  final due = DateTime.tryParse(fee.dueDate) ?? DateTime.now();
  return DateTime.now().difference(due).inDays;
}

String _statusDetail(FeeModel fee) {
  final diff = _daysOverdueOrUntilDue(fee);
  if (diff > 0) return 'Overdue by $diff day${diff == 1 ? '' : 's'}';
  if (diff == 0) return 'Due today';
  final remaining = -diff;
  return 'Due in $remaining day${remaining == 1 ? '' : 's'}';
}

String _formatDate(String iso) {
  final d = DateTime.tryParse(iso);
  if (d == null) return iso.split('T').first;
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  return '${d.day} ${months[d.month - 1]} ${d.year}';
}

/// Indian-style digit grouping, e.g. 1234567 -> "12,34,567"
String formatINR(num amount) {
  final isNegative = amount < 0;
  final digits = amount.abs().round().toString();
  String result;
  if (digits.length <= 3) {
    result = digits;
  } else {
    final last3 = digits.substring(digits.length - 3);
    var remaining = digits.substring(0, digits.length - 3);
    final parts = <String>[];
    while (remaining.length > 2) {
      parts.insert(0, remaining.substring(remaining.length - 2));
      remaining = remaining.substring(0, remaining.length - 2);
    }
    if (remaining.isNotEmpty) parts.insert(0, remaining);
    result = '${parts.join(',')},$last3';
  }
  return (isNegative ? '-₹' : '₹') + result;
}

// ─────────────────────────────────────────────────────────────────────────
// VIEW
// ─────────────────────────────────────────────────────────────────────────

class PendingFeesView extends StatefulWidget {
  const PendingFeesView({super.key});

  @override
  State<PendingFeesView> createState() => _PendingFeesViewState();
}

class _PendingFeesViewState extends State<PendingFeesView> {
  final controller = Get.find<DashboardController>();
  FeeCategory? _selectedCategory; // null = "All"

  @override
  void initState() {
    super.initState();
    // TODO: backend — if fees aren't already populated by the time this
    // screen opens, trigger your fetch here, e.g.:
    // WidgetsBinding.instance.addPostFrameCallback((_) => controller.fetchFees());
  }

  Future<void> _onRefresh() async {
    // TODO: backend — point this at your real API/Mongo fetch, e.g.:
    // await controller.fetchFees();
    await Future<void>.delayed(const Duration(milliseconds: 400));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
        title: Text('Pending Fees', style: AppTextStyles.h2),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.ink, size: 20),
          onPressed: () => Get.back(),
        ),
      ),
      body: Obx(() {
        final pending = controller.fees.where((f) => !f.isPaid).toList();

        if (pending.isEmpty) return _buildEmptyState();

        final overdue = pending.where(_isOverdue).toList();
        final dueSoon = pending.where((f) => !_isOverdue(f)).toList();
        final totalOutstanding = pending.fold<double>(0, (s, f) => s + f.remainingAmount);
        final overdueAmount = overdue.fold<double>(0, (s, f) => s + f.remainingAmount);

        final categoriesPresent = pending.map((f) => f.termName.inferredCategory).toSet();

        final filtered = _selectedCategory == null
            ? pending
            : pending.where((f) => f.termName.inferredCategory == _selectedCategory).toList();

        final grouped = _groupByPeriod(filtered);

        return RefreshIndicator(
          onRefresh: _onRefresh,
          color: AppColors.primaryMid,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            children: [
              _buildSummaryBand(totalOutstanding, overdue.length, dueSoon.length),
              if (overdue.isNotEmpty) ...[
                const SizedBox(height: 12),
                _buildOverdueBanner(overdue.length, overdueAmount),
              ],
              if (categoriesPresent.length > 1) ...[
                const SizedBox(height: 16),
                _buildCategoryChips(categoriesPresent),
              ],
              const SizedBox(height: 8),
              ..._buildGroupedSections(grouped),
            ],
          ),
        );
      }),
      bottomNavigationBar: Obx(() {
        final overdue = controller.fees.where((f) => !f.isPaid && _isOverdue(f)).toList();
        if (overdue.isEmpty) return const SizedBox.shrink();
        final overdueAmount = overdue.fold<double>(0, (s, f) => s + f.remainingAmount);
        return SafeArea(
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
            decoration: BoxDecoration(
              color: AppColors.white,
              border: Border(top: BorderSide(color: AppColors.border)),
            ),
            child: ElevatedButton(
              onPressed: () => _showBulkPaymentDialog(overdue, overdueAmount),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.red,
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(48),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 0,
              ),
              child: Text(
                'Pay Overdue Now · ${formatINR(overdueAmount)}',
                style: AppTextStyles.labelLarge.copyWith(color: Colors.white),
              ),
            ),
          ),
        );
      }),
    );
  }

  // ── Grouping ──────────────────────────────────────────────────────────

  Map<FeePeriod, List<FeeModel>> _groupByPeriod(List<FeeModel> fees) {
    final map = <FeePeriod, List<FeeModel>>{};
    for (final f in fees) {
      map.putIfAbsent(f.termName.inferredPeriod, () => []).add(f);
    }
    for (final list in map.values) {
      list.sort((a, b) {
        final aOverdue = _isOverdue(a);
        final bOverdue = _isOverdue(b);
        if (aOverdue != bOverdue) return aOverdue ? -1 : 1;
        final aDate = DateTime.tryParse(a.dueDate) ?? DateTime.now();
        final bDate = DateTime.tryParse(b.dueDate) ?? DateTime.now();
        return aDate.compareTo(bDate);
      });
    }
    return map;
  }

  List<Widget> _buildGroupedSections(Map<FeePeriod, List<FeeModel>> grouped) {
    const order = [FeePeriod.monthly, FeePeriod.term, FeePeriod.annual, FeePeriod.other];
    final widgets = <Widget>[];
    for (final period in order) {
      final fees = grouped[period];
      if (fees == null || fees.isEmpty) continue;
      widgets.add(_buildPeriodSection(period, fees));
      widgets.add(const SizedBox(height: 16));
    }
    return widgets;
  }

  // ── Sections ──────────────────────────────────────────────────────────

  Widget _buildSummaryBand(double total, int overdueCount, int dueSoonCount) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Total Outstanding', style: AppTextStyles.bodySmall),
          const SizedBox(height: 4),
          Text(
            formatINR(total),
            style: AppTextStyles.h2.copyWith(color: AppColors.primaryMid, fontSize: 26),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _miniStat(
                  label: 'Overdue',
                  value: '$overdueCount',
                  color: AppColors.red,
                  bg: AppColors.redPale,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _miniStat(
                  label: 'Due Soon',
                  value: '$dueSoonCount',
                  color: AppColors.amber,
                  bg: AppColors.amberPale,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _miniStat({required String label, required String value, required Color color, required Color bg}) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          Text(value, style: AppTextStyles.labelLarge.copyWith(color: color)),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              label,
              style: AppTextStyles.bodySmall.copyWith(color: color),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOverdueBanner(int count, double amount) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
      decoration: BoxDecoration(color: AppColors.redPale, borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          const Text('⚠️', style: TextStyle(fontSize: 16)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              '$count overdue fee${count == 1 ? '' : 's'} totaling ${formatINR(amount)}. Pay now to avoid late charges.',
              style: AppTextStyles.bodySmall.copyWith(color: AppColors.red),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryChips(Set<FeeCategory> categories) {
    final chips = <FeeCategory?>[null, ...categories];
    return SizedBox(
      height: 36,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: chips.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final category = chips[index];
          final isSelected = _selectedCategory == category;
          final label = category == null ? 'All Fees' : '${category.icon} ${category.label}';
          return GestureDetector(
            onTap: () => setState(() => _selectedCategory = category),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: isSelected ? AppColors.primaryMid : AppColors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: isSelected ? AppColors.primaryMid : AppColors.border),
              ),
              child: Center(
                child: Text(
                  label,
                  style: AppTextStyles.labelSmall.copyWith(
                    color: isSelected ? Colors.white : AppColors.ink,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildPeriodSection(FeePeriod period, List<FeeModel> fees) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            child: Row(
              children: [
                Text(period.icon, style: const TextStyle(fontSize: 16)),
                const SizedBox(width: 8),
                Expanded(child: Text(period.label, style: AppTextStyles.labelLarge)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(8)),
                  child: Text('${fees.length}', style: AppTextStyles.bodySmall),
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: AppColors.border),
          for (int i = 0; i < fees.length; i++) ...[
            _buildFeeRow(fees[i]),
            if (i != fees.length - 1) const Divider(height: 1, color: AppColors.border, indent: 14, endIndent: 14),
          ],
        ],
      ),
    );
  }

  Widget _buildFeeRow(FeeModel fee) {
    final overdue = _isOverdue(fee);
    final statusColor = overdue ? AppColors.red : AppColors.amber;
    final statusBg = overdue ? AppColors.redPale : AppColors.amberPale;
    final statusLabel = overdue ? 'Overdue' : 'Due Soon';
    final category = fee.termName.inferredCategory;

    return InkWell(
      onTap: () => _showPaymentDialog(fee),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(color: statusBg, borderRadius: BorderRadius.circular(10)),
              alignment: Alignment.center,
              child: Text(category.icon, style: const TextStyle(fontSize: 17)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(fee.termName, style: AppTextStyles.labelLarge),
                  const SizedBox(height: 2),
                  Text(
                    '${_statusDetail(fee)} · Due ${_formatDate(fee.dueDate)}',
                    style: AppTextStyles.bodySmall.copyWith(color: statusColor),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  formatINR(fee.remainingAmount),
                  style: AppTextStyles.labelLarge.copyWith(color: AppColors.ink),
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: statusBg, borderRadius: BorderRadius.circular(8)),
                  child: Text(
                    statusLabel,
                    style: AppTextStyles.labelSmall.copyWith(color: statusColor, fontSize: 10),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.check_circle_outline_rounded, size: 64, color: AppColors.teal),
          const SizedBox(height: 16),
          Text('All Fees Paid! 🎉', style: AppTextStyles.h2),
          const SizedBox(height: 8),
          Text('There are no outstanding dues on this account.', style: AppTextStyles.bodyMedium),
        ],
      ),
    );
  }

  // ── Dialogs ───────────────────────────────────────────────────────────

  void _showPaymentDialog(FeeModel fee) {
    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Confirm Payment 💳', style: AppTextStyles.h2),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(fee.termName, style: AppTextStyles.labelLarge),
            const SizedBox(height: 8),
            Text(
              'Amount to Pay: ${formatINR(fee.remainingAmount)}',
              style: AppTextStyles.h2.copyWith(color: AppColors.primaryMid),
            ),
            const SizedBox(height: 16),
            const Text(
              'Important Notice: Partial payments are disabled. The full outstanding amount must be paid.',
              style: TextStyle(color: AppColors.red, fontSize: 12, height: 1.4, fontWeight: FontWeight.w500),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: Text('Cancel', style: AppTextStyles.labelLarge.copyWith(color: AppColors.ink)),
          ),
          ElevatedButton(
            onPressed: () {
              Get.back();
              controller.payFee(fee);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryMid,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('Confirm & Pay', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _showBulkPaymentDialog(List<FeeModel> overdueFees, double total) {
    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Pay All Overdue 💳', style: AppTextStyles.h2),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 200),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for (final fee in overdueFees)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(child: Text(fee.termName, style: AppTextStyles.bodySmall)),
                            Text(formatINR(fee.remainingAmount), style: AppTextStyles.bodySmall),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const Divider(height: 20, color: AppColors.border),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Total', style: AppTextStyles.labelLarge),
                Text(
                  formatINR(total),
                  style: AppTextStyles.h2.copyWith(color: AppColors.primaryMid),
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: Text('Cancel', style: AppTextStyles.labelLarge.copyWith(color: AppColors.ink)),
          ),
          ElevatedButton(
            onPressed: () {
              Get.back();
              // NOTE: assumes DashboardController.payFee handles a single
              // fee at a time. If your backend supports a combined payment
              // intent, swap this loop for a single bulk-pay API call.
              for (final fee in overdueFees) {
                controller.payFee(fee);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.red,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('Confirm & Pay All', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}