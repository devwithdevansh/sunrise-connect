import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../../core/constants/storage_keys.dart';
import '../../../../data/repositories/fee_repository.dart';
import '../../../../data/models/fee_model.dart';
import '../../../dashboard/controllers/dashboard_controller.dart';

// ─────────────────────────────────────────────────────────────────────────────
// FEE MODEL (inline — replace with your actual import if FeeModel exists)
// ─────────────────────────────────────────────────────────────────────────────

class FeeItem {
  final String id;
  final String termName;
  final double amount;
  final DateTime dueDate;
  final bool isPaid;

  const FeeItem({
    required this.id,
    required this.termName,
    required this.amount,
    required this.dueDate,
    this.isPaid = false,
  });

  bool get isOverdue => dueDate.isBefore(DateTime.now());

  int get daysOverdueOrRemaining {
    final diff = DateTime.now().difference(dueDate).inDays;
    return diff;
  }

  String get statusLabel {
    final d = daysOverdueOrRemaining;
    if (d > 0) return 'Overdue by $d day${d == 1 ? '' : 's'}';
    if (d == 0) return 'Due today';
    return 'Due in ${-d} day${-d == 1 ? '' : 's'}';
  }

  FeeStatus get status {
    if (isOverdue) return FeeStatus.overdue;
    final d = -daysOverdueOrRemaining;
    if (d <= 30) return FeeStatus.dueSoon;
    return FeeStatus.upcoming;
  }
}

enum FeeStatus { overdue, dueSoon, upcoming }

enum FeePeriod { monthly, annual, other }

extension FeePeriodX on FeePeriod {
  String get label {
    switch (this) {
      case FeePeriod.monthly:
        return 'Monthly Fees';
      case FeePeriod.annual:
        return 'Annual / One-Time Fees';
      case FeePeriod.other:
        return 'Other Fees';
    }
  }

  String get emoji {
    switch (this) {
      case FeePeriod.monthly:
        return '📅';
      case FeePeriod.annual:
        return '🎓';
      case FeePeriod.other:
        return '🧾';
    }
  }
}

FeePeriod inferPeriod(String termName) {
  final t = termName.toLowerCase();
  if (t.contains('admission') ||
      t.contains('annual') ||
      t.contains('bag') ||
      t.contains('kit') ||
      t.contains('one-time')) {
    return FeePeriod.annual;
  }
  if (t.contains('term') || t.contains('semester') || t.contains('half')) {
    return FeePeriod.other;
  }
  return FeePeriod.monthly;
}

// ─────────────────────────────────────────────────────────────────────────────
// CONTROLLER
// ─────────────────────────────────────────────────────────────────────────────

class PendingFeesController extends GetxController
    with GetSingleTickerProviderStateMixin {
  final FeeRepository _feeRepo = FeeRepository();

  // ── Observable state ──────────────────────────────────────────────────────

  final RxList<FeeItem> fees = <FeeItem>[].obs;
  final RxSet<String> selectedIds = <String>{}.obs;
  final RxBool isLoading = false.obs;
  final RxBool isRefreshing = false.obs;

  /// True once the first API response (even an empty one) has been received.
  /// Lets the view distinguish "waiting for data" from "loaded, nothing pending".
  final RxBool hasLoadedOnce = false.obs;

  // ── Quick-select preset index (-1 = none active) ──────────────────────────
  final RxInt activeQuickSelect = (-1).obs;

  // ── Section collapse state ────────────────────────────────────────────────
  final RxMap<FeePeriod, bool> sectionExpanded = <FeePeriod, bool>{
    FeePeriod.monthly: true,
    FeePeriod.annual: true,
    FeePeriod.other: true,
  }.obs;

  // ── Animation controller for the pay bar ─────────────────────────────────
  late final AnimationController payBarController;
  late final Animation<double> payBarSlide;
  late final Animation<double> payBarFade;

  // ── Derived getters ───────────────────────────────────────────────────────

  /// All fees not yet paid — shown in the fee list.
  List<FeeItem> get pendingFees => fees.where((f) => !f.isPaid).toList();

  /// Pending fees whose due date is already past.
  List<FeeItem> get overdueFees =>
      pendingFees.where((f) => f.isOverdue).toList();

  /// Pending fees the parent has ticked for payment.
  List<FeeItem> get selectedFees =>
      pendingFees.where((f) => selectedIds.contains(f.id)).toList();

  /// Sum of selected fees — shown in the floating pay bar.
  double get selectedTotal =>
      selectedFees.fold(0.0, (sum, f) => sum + f.amount);

  /// Sum of all still-unpaid fees.
  double get totalOutstanding =>
      pendingFees.fold(0.0, (sum, f) => sum + f.amount);

  /// Sum of all overdue fees.
  double get overdueTotal => overdueFees.fold(0.0, (sum, f) => sum + f.amount);

  // ── FIX: the two getters the view needs ──────────────────────────────────

  /// Sum of fees already marked isPaid = true.
  /// Reacts automatically when paySelected() flips items to isPaid.
  double get paidTotal =>
      fees.where((f) => f.isPaid).fold(0.0, (sum, f) => sum + f.amount);

  /// Grand total across the entire fee list (paid + outstanding).
  /// Used by _SummaryCard: total = grandTotal, progress = paidTotal / grandTotal.
  double get grandTotal => paidTotal + totalOutstanding;

  // ─────────────────────────────────────────────────────────────────────────

  bool get hasSelection => selectedIds.isNotEmpty;

  Map<FeePeriod, List<FeeItem>> get groupedFees {
    final map = <FeePeriod, List<FeeItem>>{};
    for (final fee in pendingFees) {
      final period = inferPeriod(fee.termName);
      map.putIfAbsent(period, () => []).add(fee);
    }
    // Sort each group: overdue first, then ascending by due date
    for (final list in map.values) {
      list.sort((a, b) {
        if (a.isOverdue != b.isOverdue) return a.isOverdue ? -1 : 1;
        return a.dueDate.compareTo(b.dueDate);
      });
    }
    return map;
  }

  // ── Lifecycle ─────────────────────────────────────────────────────────────

  @override
  void onInit() {
    super.onInit();

    payBarController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 380),
    );

    payBarSlide = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(parent: payBarController, curve: Curves.easeOutBack),
    );

    payBarFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: payBarController, curve: Curves.easeOut),
    );

    // Drive the pay bar animation whenever selection changes
    ever(selectedIds, (_) => _syncPayBar());

    _loadFees();
  }

  @override
  void onClose() {
    payBarController.dispose();
    super.onClose();
  }

  // ── Pay bar sync ──────────────────────────────────────────────────────────

  void _syncPayBar() {
    if (selectedIds.isNotEmpty) {
      payBarController.forward();
    } else {
      payBarController.reverse();
    }
  }

  // ── Data loading (replace with your real API call) ────────────────────────

  Future<void> _loadFees() async {
    isLoading.value = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final studentId = prefs.getString(StorageKeys.studentId) ?? '';
      if (studentId.isNotEmpty) {
        final List<FeeModel> data = await _feeRepo.getFees(studentId);
        final List<FeeItem> mapped = data.map((f) => FeeItem(
          id: f.id,
          termName: f.termName,
          amount: f.isPaid ? f.amount : f.remainingAmount,
          dueDate: DateTime.tryParse(f.dueDate) ?? DateTime.now(),
          isPaid: f.isPaid,
        )).toList();
        fees.assignAll(mapped);
      }
    } catch (e) {
      print('Error in _loadFees: $e');
    } finally {
      isLoading.value = false;
      hasLoadedOnce.value = true;
    }
  }

  @override
  Future<void> refresh() async {
    isRefreshing.value = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final studentId = prefs.getString(StorageKeys.studentId) ?? '';
      if (studentId.isNotEmpty) {
        final List<FeeModel> data = await _feeRepo.getFees(studentId);
        final List<FeeItem> mapped = data.map((f) => FeeItem(
          id: f.id,
          termName: f.termName,
          amount: f.isPaid ? f.amount : f.remainingAmount,
          dueDate: DateTime.tryParse(f.dueDate) ?? DateTime.now(),
          isPaid: f.isPaid,
        )).toList();
        fees.assignAll(mapped);
      }
    } catch (e) {
      print('Error in refresh: $e');
    } finally {
      isRefreshing.value = false;
      hasLoadedOnce.value = true;
    }
  }

  // ── Selection ─────────────────────────────────────────────────────────────

  void toggleFee(FeeItem fee) {
    activeQuickSelect.value = -1;
    if (selectedIds.contains(fee.id)) {
      selectedIds.remove(fee.id);
    } else {
      selectedIds.add(fee.id);
    }
  }

  void selectAllInSection(FeePeriod period) {
    final sectionFees =
        pendingFees.where((f) => inferPeriod(f.termName) == period).toList();
    final allSelected = sectionFees.every((f) => selectedIds.contains(f.id));
    if (allSelected) {
      for (final f in sectionFees) {
        selectedIds.remove(f.id);
      }
    } else {
      for (final f in sectionFees) {
        selectedIds.add(f.id);
      }
    }
    activeQuickSelect.value = -1;
  }

  bool isSectionFullySelected(FeePeriod period) {
    final sectionFees =
        pendingFees.where((f) => inferPeriod(f.termName) == period).toList();
    if (sectionFees.isEmpty) return false;
    return sectionFees.every((f) => selectedIds.contains(f.id));
  }

  /// Quick-select N monthly fees (overdue-first, then oldest-first).
  void quickSelectMonths(int n) {
    selectedIds.clear();
    final monthly = pendingFees
        .where((f) => inferPeriod(f.termName) == FeePeriod.monthly)
        .toList();
    final count = n == 9999 ? monthly.length : n.clamp(0, monthly.length);
    for (int i = 0; i < count; i++) {
      selectedIds.add(monthly[i].id);
    }
  }

  void selectAllOverdue() {
    for (final f in overdueFees) {
      selectedIds.add(f.id);
    }
    activeQuickSelect.value = -1;
  }

  void clearSelection() {
    selectedIds.clear();
    activeQuickSelect.value = -1;
  }

  // ── Section toggle ────────────────────────────────────────────────────────

  void toggleSection(FeePeriod period) {
    sectionExpanded[period] = !(sectionExpanded[period] ?? true);
    // ignore: invalid_use_of_protected_member
    sectionExpanded.refresh();
  }

  // ── Payment ───────────────────────────────────────────────────────────────

  /// Call your real payment gateway here.
  Future<void> paySelected() async {
    final toPayItems = pendingFees.where((f) => selectedIds.contains(f.id)).toList();
    if (toPayItems.isEmpty) return;

    isLoading.value = true;
    try {
      bool allSuccess = true;
      for (final fee in toPayItems) {
        final success = await _feeRepo.payFee(fee.id, fee.amount, 'online');
        if (!success) {
          allSuccess = false;
        }
      }

      if (allSuccess) {
        final updated = fees.map((f) {
          if (selectedIds.contains(f.id)) {
            return FeeItem(
              id: f.id,
              termName: f.termName,
              amount: f.amount,
              dueDate: f.dueDate,
              isPaid: true,
            );
          }
          return f;
        }).toList();

        fees.assignAll(updated);
        selectedIds.clear();

        final prefs = await SharedPreferences.getInstance();
        final sId = prefs.getString(StorageKeys.studentId) ?? '';
        final pId = prefs.getString(StorageKeys.parentId) ?? '';
        if (sId.isNotEmpty) {
          await prefs.remove('fees_cache_$sId');
          await prefs.remove('payments_cache_$sId');
          await prefs.remove('payments_time_$sId');
        }
        if (pId.isNotEmpty) {
          await prefs.remove('student_time_$pId');
        }

        if (Get.isRegistered<DashboardController>()) {
          Get.find<DashboardController>().refreshData();
        }
      } else {
        Get.snackbar(
          'Payment Failed ❌',
          'Unable to process payment for one or more fees. Please try again.',
          snackPosition: SnackPosition.BOTTOM,
        );
      }
    } catch (e) {
      print('Error in paySelected: $e');
      Get.snackbar(
        'Payment Error ❌',
        'An error occurred during payment. Please try again.',
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isLoading.value = false;
    }
  }
}
