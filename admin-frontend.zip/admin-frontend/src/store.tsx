import React, { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import type {
  Student,
  LedgerEntry,
  PaymentTransaction
} from './mockData';
// Removed static mock data imports – data now loaded from backend

export type ScreenType =
  | 'dashboard'
  | 'collect-fee'
  | 'unpaid-fees'
  | 'fee-structure'
  | 'students'
  | 'whatsapp'
  | 'notifications'
  | 'parent-app'
  | 'receipts'
  | 'audit'
  | 'reports'
  | 'login';

interface AppContextType {
  currentScreen: ScreenType;
  setScreen: (screen: ScreenType) => void;
  students: Student[];
  ledgerEntries: LedgerEntry[];
  transactions: PaymentTransaction[];
  addStudent: (student: Omit<Student, 'id' | 'status'>) => void;
  recordPayment: (
    studentId: string,
    feesToPay: { category: string; period: string; ledgerId?: string; totalAmount: number }[],
    amountPaid: number,
    paymentMethod: PaymentTransaction['method'],
    concessionAmount: number,
    remark: string
  ) => void;
  applyConcession: (ledgerId: string, amount: number) => void;
  reversePayment: (transactionId: string) => void;
  currentUser: { name: string; role: 'ADMIN' | 'STAFF' } | null;
  login: (email: string, pass: string) => boolean;
  logout: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentScreen, setScreen] = useState<ScreenType>('dashboard');
  const [students, setStudents] = useState<Student[]>([]);
  const [ledgerEntries, setLedgerEntries] = useState<LedgerEntry[]>([]);
  const [transactions, setTransactions] = useState<PaymentTransaction[]>([]);

  // Fetch data from backend on mount and after mutations
  const fetchAll = async () => {
    try {
      const [studRes, ledRes, txRes] = await Promise.all([
        fetch('/api/v1/students'),
        fetch('/api/v1/ledgers'),
        fetch('/api/v1/payments')
      ]);
      const [studResp, ledResp, txResp] = await Promise.all([
        studRes.json(),
        ledRes.json(),
        txRes.json()
      ]);
      // Backend wraps payload in { success, data }
      setStudents(studResp.data || []);
      setLedgerEntries(ledResp.data || []);
      setTransactions(txResp.data || []);
    } catch (err) {
      console.error('Failed to fetch data from backend', err);
    }
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const [currentUser, setCurrentUser] = useState<{ name: string; role: 'ADMIN' | 'STAFF' } | null>({
    name: 'Admin User',
    role: 'ADMIN'
  });

  const login = (email: string, pass: string): boolean => {
    if (email === 'admin@school.com' && pass === 'secret123') {
      setCurrentUser({ name: 'Admin User', role: 'ADMIN' });
      setScreen('dashboard');
      return true;
    } else if (email === 'staff@school.com' && pass === 'secret123') {
      setCurrentUser({ name: 'Staff User', role: 'STAFF' });
      setScreen('dashboard');
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    setScreen('login');
  };

  const addStudent = async (newS: Omit<Student, 'id' | 'status'>) => {
    try {
      const res = await fetch('/api/v1/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newS)
      });
      if (!res.ok) throw new Error('Failed to add student');
      // Refresh data
      await fetchAll();
    } catch (err) {
      console.error(err);
    }
  };

  const recordPayment = async (
    studentId: string,
    feesToPay: { category: string; period: string; ledgerId?: string; totalAmount: number }[],
    amountPaid: number,
    paymentMethod: PaymentTransaction['method'],
    concessionAmount: number,
    remark: string
  ) => {
    try {
      const payload = {
        studentId,
        feesToPay,
        amountPaid,
        paymentMethod,
        concessionAmount,
        remark
      };
      const res = await fetch('/api/v1/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error('Failed to record payment');
      await fetchAll();
    } catch (err) {
      console.error(err);
    }
  };

  const applyConcession = (ledgerId: string, amount: number) => {
    setLedgerEntries((prev) =>
      prev.map((ledger) => {
        if (ledger.id === ledgerId) {
          const newConc = ledger.concessionAmount + amount;
          const newRemaining = Math.max(0, ledger.totalAmount - ledger.paidAmount - newConc);
          return {
            ...ledger,
            concessionAmount: newConc,
            remainingAmount: newRemaining,
            status: (newRemaining === 0 ? 'PAID' : ledger.paidAmount > 0 ? 'PARTIAL' : 'PENDING') as 'PAID' | 'PARTIAL' | 'PENDING'
          };
        }
        return ledger;
      })
    );
  };


  // Reverse a payment by calling the backend API
  const reversePayment = async (transactionId: string) => {
    try {
      const res = await fetch(`/api/v1/payments/${transactionId}/reverse`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      if (!res.ok) throw new Error('Failed to reverse payment');
      // Refresh all data after reversal
      await fetchAll();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentScreen,
        setScreen,
        students,
        ledgerEntries,
        transactions,
        addStudent,
        recordPayment,
        applyConcession,
        reversePayment,
        currentUser,
        login,
        logout
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

export default useApp;
