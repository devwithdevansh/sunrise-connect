import React from 'react';
import { feeStructureData } from '../mockData';
import { AlertCircle } from 'lucide-react';

export const FeeStructure: React.FC = () => {
  return (
    <div className="flex-1 p-6 space-y-6">
      {/* Top Header Bar */}
      <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 tracking-tight">Fee Structure</h2>
          <p className="text-xs font-semibold text-slate-400">Sunday, June 7, 2026</p>
        </div>
      </header>

      {/* Info Warning Banner */}
      <div className="bg-blue-50/50 border border-blue-100 rounded-2xl p-4 text-xs font-semibold text-blue-700 flex items-center gap-3">
        <AlertCircle className="h-5 w-5 text-blue-500 shrink-0" />
        <span>
          Total Annual Fee ÷ 14 = Monthly Installment. First 2 = Term Fees. Remaining 12 = Education Fees.
        </span>
      </div>

      {/* Twin Columns Fee Comparison Grid */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Column 1: English Medium */}
        <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden">
          {/* Header */}
          <div className="bg-[#1E3A8A] text-white p-4 flex items-center justify-between">
            <h4 className="font-extrabold text-sm tracking-wide">English Medium – All Classes</h4>
            <span className="text-xs font-bold text-blue-200">2025–26</span>
          </div>

          <div className="divide-y divide-slate-100">
            {feeStructureData.map((item, index) => {
              if (item.isHeader) {
                return (
                  <div key={index} className="bg-slate-50/50 px-5 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">
                    {item.category}
                  </div>
                );
              }
              return (
                <div key={index} className="flex justify-between items-center px-5 py-3.5 hover:bg-slate-50/30 transition-colors">
                  <span className="text-sm font-semibold text-slate-600">{item.category}</span>
                  <span className="text-sm font-extrabold text-slate-800">{item.englishVal}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Column 2: Gujarati Medium */}
        <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden">
          {/* Header */}
          <div className="bg-teal-600 text-white p-4 flex items-center justify-between">
            <h4 className="font-extrabold text-sm tracking-wide">Gujarati Medium – All Classes</h4>
            <span className="text-xs font-bold text-teal-200">2025–26</span>
          </div>

          <div className="divide-y divide-slate-100">
            {feeStructureData.map((item, index) => {
              if (item.isHeader) {
                return (
                  <div key={index} className="bg-slate-50/50 px-5 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">
                    {item.category}
                  </div>
                );
              }
              return (
                <div key={index} className="flex justify-between items-center px-5 py-3.5 hover:bg-slate-50/30 transition-colors">
                  <span className="text-sm font-semibold text-slate-600">{item.category}</span>
                  <span className="text-sm font-extrabold text-slate-800">{item.gujaratiVal}</span>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};
